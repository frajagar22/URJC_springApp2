package ELibreria.repository;

import java.util.List;
import ELibreria.model.Editorial;
import org.springframework.data.jpa.repository.JpaRepository;

public interface editorialRepository extends JpaRepository<Editorial, Long> {
		
		//Obtiene la lista de editoriales con mismo nombre
		Editorial findByNombre(String nombreEditorial);
		
		//Obtiene la editorial con ese mismo Correo
		Editorial findByCorreo(String correo);
		
		//Obtiene la editorial con ese mismo CF
		Editorial findBycf(String cf);
		
		//Obtiene la lista de todas las editoriales
		List<Editorial> findAll();
		
		//Obtiene la editorial con ese id
		Editorial findByIdEditorial(long IdEditorial);
}

