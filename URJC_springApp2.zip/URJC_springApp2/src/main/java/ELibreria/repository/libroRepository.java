package ELibreria.repository;

	import java.util.List;

	import org.springframework.data.jpa.repository.JpaRepository;
	import ELibreria.model.Libro;

	public interface libroRepository extends JpaRepository<Libro, Long> {
		
		//Obtiene la lista de libros con mismo nombre
		List<Libro> findByTitulo(String titulo);
		
		//Obtiene la lista de todos los libros 
		List<Libro> findAll();
		List<Libro> findByCategoria(String categoria);
		List<Libro> findByAutor(String autor);
	}

