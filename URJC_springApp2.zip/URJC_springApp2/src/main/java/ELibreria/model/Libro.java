package ELibreria.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;


@Entity
public class Libro implements Serializable{
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public long id;
	public String autor;
	public String titulo;
	@ManyToOne
	@JoinColumn(name = "idEditorial")
	public Editorial editorial;
	public int anio;
	public int n_paginas;
	public String isbn;
	public int precio;
	public String categoria;
	
	public Libro() {
		
	}
	public Libro(String a, String t, Editorial e,int anio, int n,String i,int p,String c) {
		this.autor=a;
		this.titulo=t;
		this.editorial=e;
		this.anio=anio;
		this.n_paginas=n;
		this.isbn=i;
		this.precio=p;
		this.categoria=c;
	}
	public String getAutor() {
		return autor;
	}
	public void setAutor(String autor) {
		this.autor = autor;
	}
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public Editorial getEditorial() {
		return editorial;
	}
	public void setEditorial(Editorial editorial) {
		this.editorial = editorial;
	}
	public int getAño() {
		return anio;
	}
	public void setAño(int año) {
		this.anio = año;
	}
	public int getN_paginas() {
		return n_paginas;
	}
	public void setN_paginas(int n_paginas) {
		this.n_paginas = n_paginas;
	}
	public String getIsbn() {
		return isbn;
	}
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	public int getPrecio() {
		return precio;
	}
	public void setPrecio(int precio) {
		this.precio = precio;
	}
	public String getCategoria() {
		return categoria;
	}
	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}
	@Override
	public String toString() {
		return "Libro [idLibro=" + id + ", autor=" + autor + ", titulo=" + titulo + ", editorial=" + editorial
				+ ", año=" + anio + ", n_paginas=" + n_paginas + ", isbn=" + isbn + ", precio=" + precio + ", categoria="
				+ categoria + "]";
	}
	
	
	

}
