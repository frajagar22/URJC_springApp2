package ELibreria.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Editorial implements Serializable {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long idEditorial;
	private String nombre;
	private int telefono;
	private String correo;
	private int cp;
	private String cf;
	
	@OneToMany(mappedBy = "editorial")
	private List<Libro> libros;
	
	public Editorial() {
		
	}
	public Editorial(String n,int t,String c,int cp,String cf) {
		this.nombre=n;
		this.telefono=t;
		this.correo=c;
		this.cp=cp;
		this.cf=cf;
		this.libros=new ArrayList<>();
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public int getTelefono() {
		return telefono;
	}
	public void setTelefono(int telefono) {
		this.telefono = telefono;
	}
	public String getCorreo() {
		return correo;
	}
	public void setCorreo(String correo) {
		this.correo = correo;
	}
	public int getcodigoPostal() {
		return cp;
	}
	public void setcodigoPostal(int codigoPostal) {
		this.cp = codigoPostal;
	}
	public String getcodigoFiscal() {
		return cf;
	}
	public void setcodigoFiscal(String codigoFiscal) {
		this.cf = codigoFiscal;
	}
	
	public void añadirLibros(Libro libro) {
		if(libros.contains(libro)) {
			System.out.println("El libro" + libro + "ya se encuentra en la librería");
		}
		libros.add(libro);
	}

}
