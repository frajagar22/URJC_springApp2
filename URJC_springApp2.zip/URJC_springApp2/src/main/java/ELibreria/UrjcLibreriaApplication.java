package ELibreria;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UrjcLibreriaApplication {

	public static void main(String[] args) {
		SpringApplication.run(UrjcLibreriaApplication.class, args);
	}
}
