package ELibreria.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import ELibreria.model.Libro;
import ELibreria.repository.*;

@Controller
public class Catalogo {
	// Conjunto de libros del catalogo
	@Autowired
	private libroRepository libros;
	// Conjunto de editoriales del catalogo
	@Autowired
	private editorialRepository editoriales;
	
	@RequestMapping("/mostrarPorTitulo")
	public String mostrarPorTitulo(@RequestParam String titulo, Model model) {

		List<Libro> l = libros.findByTitulo(titulo);

	    model.addAttribute("libros", l);

		return "mostrar";
	}
	@RequestMapping("/")
	public String mostrarPorAutor(@RequestParam String autor, Model model) {

		List<Libro> l = libros.findByAutor(autor);

    	model.addAttribute("libros", l);

		return "mostrar";
	}
	
	@RequestMapping("/")
	public String mostrarPorCategoria(@RequestParam String categoria, Model model) {

		List<Libro> l = libros.findByCategoria(categoria);

    	model.addAttribute("libros", l);

		return "mostrar";
	}
	
	
	
	

	
	
	
}
