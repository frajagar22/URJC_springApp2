package ELibreria.Controller;

import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;



import ELibreria.model.Editorial;
import ELibreria.model.Libro;
import ELibreria.repository.*;

@Controller
public class Catalogo {
	
	
	
	
	// Conjunto de libros del catalogo
	@Autowired
	private libroRepository libros;
	
	// Conjunto de editoriales del catalogo
	@Autowired
	private editorialRepository editoriales;
	
	
	
	@PostConstruct
	public void init() {
		Editorial editorial1 = new Editorial("SM", 695334672, "r.rodriguezrec@alumnos.urjc.es", 28941, "457371");
		editoriales.save(editorial1);
		Libro libro = new Libro("Raquel", "Hola que tal", editorial1, 1997, 10, "numisbn", 30, "Animales");
		libros.save(libro);
	}
	
	
	@RequestMapping("/mostrarPorTitulo")
	public String mostrarPorTitulo(@RequestParam String titulo, Model model) {

		List<Libro> l = libros.findByTitulo(titulo);

	    model.addAttribute("libros", l);

		return "mostrar";
	}
	@RequestMapping("/mostrarPorAutor")
	public String mostrarPorAutor(@RequestParam String autor, Model model) {

		List<Libro> l = libros.findByAutor(autor);

		model.addAttribute("libros", l);

		return "mostrar";
	}
	
	@RequestMapping("/mostrarPorCategoria")
	public String mostrarPorCategoria(@RequestParam String categoria, Model model) {

		List<Libro> l = libros.findByCategoria(categoria);

		model.addAttribute("libros", l);

		return "mostrar";
	}
	
	
	@RequestMapping(value = "/nuevoLibro")
	public String guardarLibro(Model model) {
		return "nuevoLibro";
	}
	
	
	@RequestMapping(value = "/subirNuevoLibro")
	public String guardar(Model model, @RequestParam String autor,@RequestParam String titulo, 
						 @RequestParam String editorial, @RequestParam int anio, 
						 @RequestParam int n_paginas, @RequestParam String isbn, 
						 @RequestParam int precio, @RequestParam String categoria) {
		
		
		Editorial edit = editoriales.findByNombre(editorial);
		
		Libro libro = new Libro(autor, titulo, edit, anio, n_paginas, isbn, precio, categoria);
		
		
		//model.addAttribute("inserta","EL LIBRO HA SIDO METIDO CORRECTAMENTE");
		
		libros.save(libro);
		
		
		return "libroSubido"; 

	}
	

	
	@RequestMapping("/libroSubido")
	public String libroSubido(Model model) {

		List<Libro> librillos = libros.findAll();
	

	    model.addAttribute("librillos", librillos);
	    
		return "libroSubido";
		
	}
	

	@RequestMapping("/catalogo")
	public String mostrarCatalogo(Model model) {
		model.addAttribute("libros",libros.findAll());
		List<Libro> librillos = libros.findAll();
		return "catalogo";
		
	}
	
	@RequestMapping("/editarLibro")
	public String editarLibro(Model model,@RequestParam(value = "id") long id, @RequestParam String autor,@RequestParam String titulo, 
							 @RequestParam String editorial, @RequestParam int anio, @RequestParam int n_paginas, 
							 @RequestParam String isbn, @RequestParam int precio, @RequestParam String categoria) {
		Libro libro = libros.findById(id);
		Editorial edit = editoriales.findByNombre(editorial);
		libro.setAutor(autor);
		libro.setAño(anio);
		libro.setEditorial(edit);
		libro.setN_paginas(n_paginas);
		libro.setIsbn(isbn);
		libro.setPrecio(precio);
		libro.setCategoria(categoria);
		libros.save(libro);
		model.addAttribute("libro", libro);
		return "editarLibro";
	}
	
	
	
	
	

	
	
	
}
