package ELibreria.Controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;



import ELibreria.model.Editorial;
import ELibreria.model.Libro;
import ELibreria.repository.*;

@Controller
public class CatalogoLibros {
	
	
	
	
	// Conjunto de libros del catalogo
	@Autowired
	private libroRepository libros;
	
	// Conjunto de editoriales del catalogo
	@Autowired
	private editorialRepository editoriales;
	
	private String busqueda;
	
	@PostConstruct
	public void init() {
		Editorial editorial2 = new Editorial("Editorial2", 69835467, "dparla@hotmail.es", 28941, "456666");
		editoriales.save(editorial2);
		Editorial editorial1 = new Editorial("SM", 695334672, "r.rodriguezrec@alumnos.urjc.es", 28941, "457371");
		editoriales.save(editorial1);
		Libro libro2 = new Libro("Parla", "Holitta", editorial1, 1990, 12, "numisbn2", 35, "Terror");
		Libro libro = new Libro("Raquel", "Hola que tal", editorial1, 1997, 10, "numisbn", 30, "Animales");
		libros.save(libro);
		libros.save(libro2);
	}
	
	@RequestMapping("/catalogoLibros")
	public String mostrarCatalogo(Model model) {
		model.addAttribute("libros",libros.findAll());
		busqueda=null;
		return "catalogoLibros";
		
	}
	
/********************************  Modificar libros ******************************/	
	
	@RequestMapping(value = "/nuevoLibro")
	public String guardarLibro(Model model) {
		return "nuevoLibro";
	}
	
	
	@RequestMapping(value = "/subirNuevoLibro")
	public String guardar(Model model, @RequestParam String autor,@RequestParam String titulo, 
						 @RequestParam String editorial, @RequestParam int anio, 
						 @RequestParam int n_paginas, @RequestParam String isbn, 
						 @RequestParam int precio, @RequestParam String categoria) {
		
		
		Editorial edit = editoriales.findByNombre(editorial);
		
		Libro libro = new Libro(autor, titulo, edit, anio, n_paginas, isbn, precio, categoria);
		
		
		//model.addAttribute("inserta","EL LIBRO HA SIDO METIDO CORRECTAMENTE");
		
		libros.save(libro);
		
		
		return "libroSubido"; 

	}
	
	@RequestMapping("/libroSubido")
	public String libroSubido(Model model) {

		List<Libro> librillos = libros.findAll();
	

	    model.addAttribute("librillos", librillos);
	    
		return "libroSubido";
		
	}
	
	@RequestMapping("/editarLibro")
	public String editarLibro(Model model,@RequestParam(value = "id") long id, @RequestParam String autor,@RequestParam String titulo, 
							 @RequestParam String editorial, @RequestParam int anio, @RequestParam int n_paginas, 
							 @RequestParam String isbn, @RequestParam int precio, @RequestParam String categoria) {
		Libro libro = libros.findById(id);
		Editorial edit = editoriales.findByNombre(editorial);
		libro.setAutor(autor);
		libro.setAnio(anio);
		libro.setEditorial(edit);
		libro.setN_paginas(n_paginas);
		libro.setIsbn(isbn);
		libro.setPrecio(precio);
		libro.setCategoria(categoria);
		libros.save(libro);
		model.addAttribute("libro", libro);
		return "editarLibro";
	}
	
/****************************************  Buscar Libros **********************************/
	
	@RequestMapping("/busqueda")
	public String busqueda(@RequestParam String query,Model model) {
		List <Libro> l = new ArrayList<>();
		l.addAll(libros.findByAutor(query));
		l.addAll(libros.findByCategoria(query));
		l.addAll(libros.findByTitulo(query));
		busqueda=query;
		model.addAttribute("libros", l);
		return "catalogoLibros";
	}
	
	
	
/****************************************  Ordenar Libros *********************************/

	@RequestMapping("/mostrarPorTitulo")
	public String mostrarPorTitulo(Model model) {
		List<Libro> l;
		if (busqueda != null) {
			l = libros.findByAutor(busqueda);
			l.addAll(libros.findByTitulo(busqueda));
			l.addAll(libros.findByCategoria(busqueda));
		} else {
			l = libros.findAll();	
		}
		Collections.sort(l, new Comparator<Libro>() {
			public int compare(Libro o1,Libro o2) {
				return o1.getTitulo().compareTo(o2.getTitulo());
			}
		});
		model.addAttribute("libros", l);
		
		return "catalogoLibros";
	}
	@RequestMapping("/mostrarPorAutor")
	public String mostrarPorAutor(Model model) {

		List<Libro> l;
		if (busqueda != null) {
			l = libros.findByAutor(busqueda);
			l.addAll(libros.findByTitulo(busqueda));
			l.addAll(libros.findByCategoria(busqueda));
		} else {
			l = libros.findAll();	
		}
		Collections.sort(l, new Comparator<Libro>() {
			public int compare(Libro o1,Libro o2) {
				return o1.getAutor().compareTo(o2.getAutor());
			}
		});
		model.addAttribute("libros", l);
		
		return "catalogoLibros";
	}
	
	@RequestMapping("/mostrarPorPrecio")
	public String mostrarPorPrecio(Model model) {

		List<Libro> l;
		if (busqueda != null) {
			l = libros.findByAutor(busqueda);
			l.addAll(libros.findByTitulo(busqueda));
			l.addAll(libros.findByCategoria(busqueda));
		} else {
			l = libros.findAll();	
		}
		Collections.sort(l, new Comparator<Libro>() {
			public int compare(Libro o1,Libro o2) {
				Integer a = o1.getPrecio();
				Integer b = o2.getPrecio();
				return a.compareTo(b);
			}
		});
		model.addAttribute("libros", l);
		
		return "catalogoLibros";
	}

}
