package ELibreria.Controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;



import ELibreria.model.Editorial;
import ELibreria.repository.*;

@Controller
public class CatalogoEditoriales {

	// Conjunto de editoriales del catalogo
		@Autowired
		private editorialRepository editoriales;
		
		@RequestMapping("/catalogoEditoriales")
		public String mostrarCatalogo(Model model) {
			model.addAttribute("editoriales",editoriales.findAll());
			return "catalogoEditoriales";			
		}
		
/********************************  Modificar editoriales ******************************/	
		
		@RequestMapping(value = "/nuevaEditorial")
		public String guardarEditorial(Model model) {
			return "nuevaEditorial";
		}
		
		@RequestMapping(value = "/subirNuevaEditorial")
		public String guardar(Model model,@RequestParam(value = "idEditorial") long idEditorial, @RequestParam String nombre,@RequestParam String correo, 
				 @RequestParam String cf, @RequestParam int cp, @RequestParam int telefono) {
			
			
			Editorial editorial = new Editorial(nombre, telefono, correo, cp, cf);
			
			
			
			
			editoriales.save(editorial);
			
			
			return "editorialSubida"; 

		}
		
		@RequestMapping("/editorialSubida")
		public String editorialSubida(Model model) {

			List<Editorial> editorialillas = editoriales.findAll();
		

		    model.addAttribute("editorialillas", editorialillas);
		    
			return "editorialSubida";
			
		}
		
		@RequestMapping("/editarEditorial")
		public String editarEditorial(Model model,@RequestParam(value = "idEditorial") long idEditorial, @RequestParam String nombre,@RequestParam String correo, 
								 @RequestParam String codigoFiscal, @RequestParam int codigoPostal, @RequestParam int telefono) {
			Editorial editorial = editoriales.findByIdEditorial(idEditorial);
			editorial.setNombre(nombre);
			editorial.setTelefono(telefono);
			editorial.setCorreo(correo);
			editorial.setcodigoFiscal(codigoFiscal);
			editorial.setcodigoPostal(codigoPostal);
			
			model.addAttribute("editorial", editorial);
			return "editarEditorial";
		}
		
	/****************************************  Buscar **********************************/
		
		@RequestMapping("/busquedaEditorial")
		public String busqueda(@RequestParam String query,Model model) {
			List <Editorial> e = new ArrayList<>();
			e.add(editoriales.findByNombre(query));
			e.add(editoriales.findByCorreo(query));
			e.add(editoriales.findBycf(query));
			
			model.addAttribute("editoriales", e);
			return "catalogoEditoriales";
		}
		
		
		
	/****************************************  Ordenar *********************************/

		@RequestMapping("/mostrarPorNombre")
		public String mostrarPorNombre(@RequestParam String busqueda,Model model) {
			List<Editorial> e=new ArrayList<>();
			if (busqueda != null) {
				e.add(editoriales.findByNombre(busqueda));
				e.add(editoriales.findByCorreo(busqueda));
				e.add(editoriales.findBycf(busqueda));
			} else {
				e = editoriales.findAll();	
			}
			Collections.sort(e, new Comparator<Editorial>() {
				public int compare(Editorial o1,Editorial o2) {
					return o1.getNombre().compareTo(o2.getNombre());
				}
			});
			model.addAttribute("editoriales", e);
			
			return "catalogoEditoriales";
		}
		@RequestMapping("/mostrarPorCorreo")
		public String mostrarPorCorreo(@RequestParam String busqueda, Model model) {
			List<Editorial> e=new ArrayList<>();
			if (busqueda != null) {
				e.add(editoriales.findByNombre(busqueda));
				e.add(editoriales.findByCorreo(busqueda));
				e.add(editoriales.findBycf(busqueda));
			} else {
				e = editoriales.findAll();	
			}
			Collections.sort(e, new Comparator<Editorial>() {
				public int compare(Editorial o1,Editorial o2) {
					return o1.getCorreo().compareTo(o2.getCorreo ());
				}
			});
			model.addAttribute("editoriales", e);

			return "catalogoEditoriales";
		}
		
		@RequestMapping("/mostrarPorCF")
		public String mostrarPorCodigoFiscal(@RequestParam String busqueda, Model model) {
			List<Editorial> e=new ArrayList<>();
			if (busqueda != null) {
				e.add(editoriales.findByNombre(busqueda));
				e.add(editoriales.findByCorreo(busqueda));
				e.add(editoriales.findBycf(busqueda));
			} else {
				e = editoriales.findAll();	
			}
			Collections.sort(e, new Comparator<Editorial>() {
				public int compare(Editorial o1,Editorial o2) {
					return o1.getcodigoFiscal().compareTo(o2.getcodigoFiscal());
				}
			});
			model.addAttribute("editoriales", e);

			return "catalogoEditoriales";
		}
}
