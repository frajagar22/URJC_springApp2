package ELibreria.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import ELibreria.model.Libro;
import ELibreria.repository.*;



@Controller
public class Catalogo {
	// Conjunto de libros del catalogo
	@Autowired
	private libroRepository libros;
	// Conjunto de editoriales del catalogo
	@Autowired
	private editorialRepository editoriales;
	
	@RequestMapping("/")
	public String mostrarPorTitulo(@RequestParam String titulo, Model model) {

		List<Libro> l = libros.findByTitulo(titulo);

	    model.addAttribute("libros", l);

		return "mostrar";
	}
	@RequestMapping("/")
	public String mostrarPorAutor(@RequestParam String autor, Model model) {

		List<Libro> l = libros.findByAutor(autor);

    	model.addAttribute("libros", l);

		return "mostrar";
	}
	
	@RequestMapping("/")
	public String mostrarPorCategoria(@RequestParam String categoria, Model model) {

		List<Libro> l = libros.findByCategoria(categoria);

    	model.addAttribute("libros", l);

		return "mostrar";
	}
	
	@RequestMapping("/libro/nuevo")
	public String nuevoLibro(Model model, Libro libro) {

		model.addAttribute(libro);
		model.addAttribute("titulo", libro.getTitulo());
		model.addAttribute("autor", libro.getAutor());
		model.addAttribute("editorial",libro.getEditorial());
		model.addAttribute("categoria", libro.getCategoria());
		return "libro_nuevo";

	}
	
	@RequestMapping("/libro/{titutlo}/borrar")
	public String borrarAnuncio(Model model, Libro libro) {

		libros.delete(libro);
		model.addAttribute("libro", libro);
		return "libro_borrado";
	}
	
	
	@RequestMapping("/libro/guardar")
	public String nuevoLibroGuardar(Model model, Libro libro) {
		libro.setAutor(libro.getAutor());
		libro.setTitulo(libro.getTitulo());
		libro.setCategoria(libro.getCategoria());
		libro.setEditorial(libro.getEditorial());		
		return "libro_guardado";
	}
	
	

	
	
	
}
